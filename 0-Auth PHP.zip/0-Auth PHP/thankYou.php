?text=Hello Mr <?php echo $row['name'] ?>,

This message is to inform you that, You have been
successfully added as a customer at <XYZ>.
Please verify your details if they are correct or they needs
to be changed

Name: <?php echo $row['name'] ?>
<!-- Age: [Age of the Customer] //to be calculated as per the
date given in the form -->
Email: <?php echo $row['email']; ?>
<!-- Phone: [Phone Number of the Customer] -->

If the Details given are correct, please reply as “CORRECT”.
If any changes need to be made, reply as “To be Changed”.


Please reply within 48 hrs of recieveing this message or we
will assume your reply as “CORRECT”.

Thanks and regards
Team <XYZ>